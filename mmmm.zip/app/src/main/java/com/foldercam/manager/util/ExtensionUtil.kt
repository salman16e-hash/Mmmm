package com.foldercam.manager.util

import java.io.File

object ExtensionUtil {
    fun getExtension(file: File): String {
        return file.extension
    }
}
