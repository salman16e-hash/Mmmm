package com.foldercam.manager.viewmodel

import androidx.lifecycle.ViewModel

class CameraViewModel : ViewModel() {
    // Used to manage camera state if needed, currently CameraX handles most of it
}
