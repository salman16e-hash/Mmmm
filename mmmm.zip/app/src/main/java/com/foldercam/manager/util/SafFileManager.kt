package com.foldercam.manager.util

import com.foldercam.manager.model.FileItem

class SafFileManager : FileManager {
    // Placeholder for SAF implementation, DirectFileManager is used with MANAGE_EXTERNAL_STORAGE
    override suspend fun listFiles(path: String): List<FileItem> = emptyList()
    override suspend fun delete(path: String): Boolean = false
    override suspend fun rename(path: String, newName: String): Boolean = false
    override suspend fun createFolder(parentPath: String, name: String): Boolean = false
}
