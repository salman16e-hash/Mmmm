package com.foldercam.manager.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.foldercam.manager.R
import com.foldercam.manager.databinding.ItemFileGridBinding
import com.foldercam.manager.databinding.ItemFileListBinding
import com.foldercam.manager.model.FileItem
import com.foldercam.manager.model.ViewMode
import com.foldercam.manager.util.FileSizeFormatter
import java.text.SimpleDateFormat
import java.util.*

class FileAdapter(
    private val onItemClick: (FileItem) -> Unit,
    private val onItemLongClick: (FileItem) -> Unit
) : ListAdapter<FileItem, RecyclerView.ViewHolder>(FileItemDiffCallback()) {

    private var viewMode = ViewMode.LIST

    fun setViewMode(mode: ViewMode) {
        viewMode = mode
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        return if (viewMode == ViewMode.LIST) 0 else 1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == 0) {
            val binding = ItemFileListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            ListViewHolder(binding)
        } else {
            val binding = ItemFileGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            GridViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val file = getItem(position)
        if (holder is ListViewHolder) holder.bind(file)
        else if (holder is GridViewHolder) holder.bind(file)
    }

    inner class ListViewHolder(private val binding: ItemFileListBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(file: FileItem) {
            binding.txtFileName.text = file.name
            
            val date = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(file.lastModified))
            val details = if (file.isDirectory) date else "$date • ${FileSizeFormatter.formatSize(file.size)}"
            binding.txtFileDetails.text = details

            binding.imgThumbnail.setImageResource(getFileIcon(file))
            if (!file.isDirectory && isImage(file)) {
                binding.imgThumbnail.load(file.toFile())
            }

            binding.root.setOnClickListener { onItemClick(file) }
            binding.root.setOnLongClickListener {
                onItemLongClick(file)
                true
            }
        }
    }

    inner class GridViewHolder(private val binding: ItemFileGridBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(file: FileItem) {
            binding.txtFileName.text = file.name
            
            binding.imgThumbnail.setImageResource(getFileIcon(file))
            if (!file.isDirectory && isImage(file)) {
                binding.imgThumbnail.load(file.toFile())
            }

            binding.root.setOnClickListener { onItemClick(file) }
            binding.root.setOnLongClickListener {
                onItemLongClick(file)
                true
            }
        }
    }

    private fun getFileIcon(file: FileItem): Int {
        if (file.isDirectory) return R.drawable.ic_folder
        return when (file.extension.lowercase()) {
            "jpg", "jpeg", "png", "webp", "gif" -> R.drawable.ic_image
            "mp4", "mkv", "avi" -> R.drawable.ic_video
            "mp3", "wav", "ogg" -> R.drawable.ic_audio
            "pdf" -> R.drawable.ic_pdf
            "apk" -> R.drawable.ic_apk
            else -> R.drawable.ic_file
        }
    }

    private fun isImage(file: FileItem): Boolean {
        return file.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp", "gif")
    }
}
