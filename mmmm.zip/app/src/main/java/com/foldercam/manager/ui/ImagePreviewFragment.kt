package com.foldercam.manager.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import coil.load
import com.foldercam.manager.databinding.FragmentImagePreviewBinding
import java.io.File

class ImagePreviewFragment : Fragment() {

    private var _binding: FragmentImagePreviewBinding? = null
    private val binding get() = _binding!!
    private val args: ImagePreviewFragmentArgs by navArgs()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentImagePreviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        val file = File(args.filePath)
        binding.toolbar.title = file.name
        binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }
        
        binding.photoView.load(file)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
