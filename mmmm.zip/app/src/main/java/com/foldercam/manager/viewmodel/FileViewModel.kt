package com.foldercam.manager.viewmodel

import android.app.Application
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.foldercam.manager.model.FileItem
import com.foldercam.manager.model.SortMode
import com.foldercam.manager.model.ViewMode
import com.foldercam.manager.util.DirectFileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class FileViewModel(application: Application) : AndroidViewModel(application) {

    private val fileManager = DirectFileManager()
    
    private val _currentPath = MutableLiveData<String>()
    val currentPath: LiveData<String> = _currentPath

    private val _files = MutableLiveData<List<FileItem>>()
    val files: LiveData<List<FileItem>> = _files

    private val _viewMode = MutableLiveData<ViewMode>(ViewMode.LIST)
    val viewMode: LiveData<ViewMode> = _viewMode

    private val _sortMode = MutableLiveData<SortMode>(SortMode.NAME_ASC)
    val sortMode: LiveData<SortMode> = _sortMode

    private var query: String = ""

    init {
        val root = Environment.getExternalStorageDirectory().absolutePath
        _currentPath.value = root
        refreshFiles()
    }

    fun setPath(path: String) {
        if (path == "root") {
            _currentPath.value = Environment.getExternalStorageDirectory().absolutePath
        } else {
            _currentPath.value = path
        }
        refreshFiles()
    }

    fun setViewMode(mode: ViewMode) {
        _viewMode.value = mode
    }

    fun setSortMode(mode: SortMode) {
        _sortMode.value = mode
        refreshFiles()
    }

    fun setSearchQuery(newQuery: String) {
        query = newQuery
        refreshFiles()
    }

    fun refreshFiles() {
        val path = _currentPath.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val list = fileManager.listFiles(path)
            
            val filtered = if (query.isEmpty()) list else {
                list.filter { it.name.contains(query, ignoreCase = true) }
            }

            val sorted = when (_sortMode.value ?: SortMode.NAME_ASC) {
                SortMode.NAME_ASC -> filtered.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                SortMode.NAME_DESC -> filtered.sortedWith(compareBy<FileItem>({ !it.isDirectory }).thenByDescending { it.name.lowercase() })
                SortMode.DATE_ASC -> filtered.sortedWith(compareBy({ !it.isDirectory }, { it.lastModified }))
                SortMode.DATE_DESC -> filtered.sortedWith(compareBy<FileItem>({ !it.isDirectory }).thenByDescending { it.lastModified })
                SortMode.SIZE_ASC -> filtered.sortedWith(compareBy({ !it.isDirectory }, { it.size }))
                SortMode.SIZE_DESC -> filtered.sortedWith(compareBy<FileItem>({ !it.isDirectory }).thenByDescending { it.size })
            }
            
            _files.postValue(sorted)
        }
    }

    fun createFolder(name: String, callback: (Boolean, String?) -> Unit) {
        val path = _currentPath.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = fileManager.createFolder(path, name)
            if (result) {
                refreshFiles()
                callback(true, null)
            } else {
                callback(false, "Failed to create folder")
            }
        }
    }

    fun deleteFile(fileItem: FileItem, callback: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = fileManager.delete(fileItem.path)
            if (result) {
                refreshFiles()
            }
            callback(result)
        }
    }

    fun renameFile(fileItem: FileItem, newName: String, callback: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = fileManager.rename(fileItem.path, newName)
            if (result) {
                refreshFiles()
            }
            callback(result)
        }
    }
}
