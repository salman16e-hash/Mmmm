package com.foldercam.manager.model

enum class ViewMode {
    LIST, GRID
}
